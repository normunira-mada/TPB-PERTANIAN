# Google Calendar Sync

Untuk sync automatik dengan Google Calendar TPB(P):

1. Daftarkan Google Cloud project.
2. Aktifkan Google Calendar API.
3. Konfigurasikan OAuth 2.0.
4. Simpan OAuth credentials sebagai Supabase Edge Function secrets, bukan dalam browser.
5. Edge Function ini menerima operasi create/update/delete dan menggunakan Google Calendar API untuk menyelaraskan event.
6. Simpan `google_event_id` pada `public.programs`.

Buat masa ini frontend menggunakan `google_event_url` jika ada; jika tiada, ia menjana pautan "Tambah ke Google Calendar".

Jangan letakkan Google client secret atau Supabase service-role key dalam `app/`.
