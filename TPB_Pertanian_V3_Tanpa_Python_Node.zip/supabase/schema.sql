create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.programs (
  id uuid primary key default gen_random_uuid(),
  event_date date not null,
  start_time time not null,
  end_time time,
  title text not null,
  location text,
  notes text,
  status text not null default 'upcoming'
    check (status in ('upcoming','ongoing','done','postponed','cancelled')),
  created_by uuid references auth.users(id),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Maklumat Google Calendar DIPISAHKAN daripada jadual awam.
-- Hanya pentadbir yang boleh membaca/menulis jadual ini.
create table if not exists public.program_google_events (
  program_id uuid primary key references public.programs(id) on delete cascade,
  google_event_id text,
  google_event_url text,
  calendar_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Jika database lama masih mempunyai medan Google pada programs, pindahkan data dahulu
-- secara manual/berjadual sebelum menjalankan DROP COLUMN di bawah.
alter table public.programs drop column if exists google_event_id;
alter table public.programs drop column if exists google_event_url;

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  program_id uuid,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  changed_by uuid,
  changed_at timestamptz not null default now(),
  old_data jsonb,
  new_data jsonb
);

create index if not exists programs_event_date_idx on public.programs(event_date);
create index if not exists programs_title_idx on public.programs(title);
create index if not exists audit_program_idx on public.audit_log(program_id);

alter table public.admin_users enable row level security;
alter table public.programs enable row level security;
alter table public.program_google_events enable row level security;
alter table public.audit_log enable row level security;

drop policy if exists "public can read programs" on public.programs;
create policy "public can read programs"
on public.programs for select
to anon, authenticated
using (true);

drop policy if exists "admins can insert programs" on public.programs;
create policy "admins can insert programs"
on public.programs for insert
to authenticated
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can update programs" on public.programs;
create policy "admins can update programs"
on public.programs for update
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can delete programs" on public.programs;
create policy "admins can delete programs"
on public.programs for delete
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Google Calendar: ADMIN SAHAJA. Tiada policy untuk anon.
drop policy if exists "admins can read google events" on public.program_google_events;
create policy "admins can read google events"
on public.program_google_events for select
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can insert google events" on public.program_google_events;
create policy "admins can insert google events"
on public.program_google_events for insert
to authenticated
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can update google events" on public.program_google_events;
create policy "admins can update google events"
on public.program_google_events for update
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can delete google events" on public.program_google_events;
create policy "admins can delete google events"
on public.program_google_events for delete
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "admins can read admin list" on public.admin_users;
create policy "admins can read admin list"
on public.admin_users for select
to authenticated
using (user_id = auth.uid());

drop policy if exists "admins can read audit" on public.audit_log;
create policy "admins can read audit"
on public.audit_log for select
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

create or replace function public.set_program_updated_at()
returns trigger
language plpgsql
security invoker
as $$
begin
  new.updated_at = now();
  if auth.uid() is not null then
    new.updated_by = auth.uid();
    if tg_op = 'INSERT' then
      new.created_by = auth.uid();
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_program_updated_at on public.programs;
create trigger trg_program_updated_at
before insert or update on public.programs
for each row execute function public.set_program_updated_at();

create or replace function public.set_google_event_updated_at()
returns trigger
language plpgsql
security invoker
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_google_event_updated_at on public.program_google_events;
create trigger trg_google_event_updated_at
before insert or update on public.program_google_events
for each row execute function public.set_google_event_updated_at();

create or replace function public.audit_program_changes()
returns trigger
language plpgsql
security invoker
as $$
begin
  insert into public.audit_log(program_id, action, changed_by, old_data, new_data)
  values (
    coalesce(new.id, old.id),
    tg_op,
    auth.uid(),
    case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end,
    case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) else null end
  );
  return coalesce(new, old);
end;
$$;

drop trigger if exists trg_program_audit on public.programs;
create trigger trg_program_audit
after insert or update or delete on public.programs
for each row execute function public.audit_program_changes();

alter publication supabase_realtime add table public.programs;
