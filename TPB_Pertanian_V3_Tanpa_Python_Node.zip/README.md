# Program Bulanan Timbalan Pengurus Besar (Pertanian) — v1

Versi ini ialah scaffold yang hampir siap untuk dipasang pada hosting. Ia menggunakan:

- Frontend: HTML/CSS/JavaScript
- Database & Realtime: Supabase
- Admin: Supabase Auth + role table
- Pengguna biasa: boleh melihat jadual melalui link tanpa login
- Audit trail: setiap perubahan direkodkan
- Arkib: paparan sejarah sehingga 20 tahun
- Google Calendar: ruang integrasi disediakan; sambungan dua hala memerlukan OAuth + Google Calendar API melalui backend/Edge Function

## 1. Cipta projek Supabase

Cipta satu projek di Supabase dan buka SQL Editor.

Jalankan fail:

`supabase/schema.sql`

Kemudian aktifkan Realtime untuk jadual `programs`. RLS dalam SQL mengehadkan operasi tulis kepada admin.

## 2. Cipta akaun admin

Dalam Supabase Dashboard:
Authentication > Users > Add user

Selepas user diwujudkan, ambil UUID user tersebut dan jalankan:

```sql
insert into public.admin_users (user_id, display_name)
values ('UUID-USER-ANDA', 'Admin Program TPB(P)');
```

## 3. Masukkan URL dan anon key

Buka `app/config.js` dan gantikan:

```js
SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
SUPABASE_ANON_KEY: "YOUR-ANON-KEY"
```

Jangan masukkan `service_role` key ke dalam frontend.

## 4. Jalankan

Untuk ujian tempatan, gunakan web server ringkas, contohnya VS Code Live Server atau:

```bash
python -m http.server 8080
```

Kemudian buka `http://localhost:8080/app/`.

## 5. Google Calendar

Versi ini sudah menyediakan butang "Tambah ke Google Calendar" menggunakan pautan event yang dijana daripada maklumat program.

Untuk sync automatik dengan Google Calendar TPB(P), gunakan Google Calendar API melalui backend/Edge Function. Jangan simpan Google OAuth client secret di browser.

## 6. Deployment

Folder `app/` boleh dihoskan pada mana-mana static hosting yang menyokong HTTPS. Supabase kekal sebagai database pusat.

## Rekaan akses

- Pengguna biasa: SELECT jadual sahaja.
- Admin: SELECT + INSERT + UPDATE + DELETE.
- Audit log: direkodkan oleh database.
- Semua pengguna melihat data yang sama.
- Realtime: perubahan INSERT/UPDATE/DELETE boleh muncul pada browser tanpa refresh.


## Model akses Google Calendar (dikemas kini)
- Semua staf boleh membuka pautan portal dan melihat jadual, arkib dan carian.
- Google Calendar TPB(P) adalah **ADMIN SAHAJA**.
- Maklumat `google_event_id`, `google_event_url` dan `calendar_id` disimpan dalam jadual private `program_google_events`.
- RLS membenarkan hanya pengguna yang tersenarai dalam `admin_users` membaca/menulis maklumat Google Calendar.
- Pengguna biasa tidak menerima medan Google Calendar dalam query jadual `programs`.
- Untuk integrasi Google Calendar sebenar, gunakan Supabase Edge Function/backend dan simpan credential Google sebagai secrets; jangan letak service-role key atau OAuth secret dalam JavaScript frontend.


VERSI 3 UJIAN LOKAL
Portal app menggunakan REST API Supabase secara terus untuk ujian tanpa Python/Node.js atau CDN Supabase JS.
