# Reka bentuk sistem

## Akses
- Semua staf MADA: lihat jadual melalui link.
- Admin: login untuk tambah/edit/padam.
- Tiada pendaftaran pengguna umum.

## Data
Setiap program mempunyai tarikh, masa, tajuk, lokasi, catatan, status dan ID event Google.

## Arkib
Data tidak dipadam apabila bulan/tahun berlalu. UI memaparkan sejarah 20 tahun. Database boleh menyimpan lebih lama jika organisasi mahu.

## Realtime
Browser melanggan perubahan pada `programs`. Apabila admin insert/update/delete, pengguna yang sedang membuka halaman akan memuatkan semula data.

## Audit
Setiap insert/update/delete masuk ke `audit_log`.

## Keselamatan
- Anon: SELECT sahaja.
- Authenticated admin: INSERT/UPDATE/DELETE.
- RLS wajib kekal aktif.
- Jangan expose service-role key.


### Kawalan akses Google Calendar
Google Calendar TPB(P) hanya tersedia kepada Admin. Data Google Calendar diasingkan daripada `programs` ke `program_google_events` dengan RLS admin-only. Paparan pengguna biasa tidak mempunyai butang/pautan Google Calendar dan payload program awam tidak mengandungi URL/ID Google Calendar.
